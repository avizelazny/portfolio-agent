"""
funds_connector.py
------------------
Connector לקרנות נאמנות ישראליות (TTF + כספיות)
מביא NAV יומי דרך MAYA API של הבורסה לניירות ערך בתל אביב

Endpoint: http://mayaapi.tase.co.il/api/fund/details?fundId=XXXXXXX
ציבורי, חינמי, ללא API key
"""

import requests
import logging
from datetime import datetime, date
from typing import Optional
from dataclasses import dataclass

logger = logging.getLogger(__name__)

# ========================================
# הגדרת הקרנות בתיק
# ========================================

PORTFOLIO_FUNDS = {
    "5136544": {
        "name": "מיטב כספית שקלית כשרה",
        "type": "money_market",       # קרן כספית
        "currency": "ILS",
        "benchmark": "ריבית בנק ישראל",
        "sector": "שוק כסף",
    },
    "5130066": {
        "name": "הראל מחקה ת\"א 35",
        "type": "tracking",           # קרן מחקה
        "currency": "ILS",
        "benchmark": "TA-35",
        "sector": "מדד ת\"א 35",
    },
    "5109418": {
        "name": "תכלית TTF ת\"א 35",
        "type": "tracking",
        "currency": "ILS",
        "benchmark": "TA-35",
        "sector": "מדד ת\"א 35",
    },
    "5134556": {
        "name": "תכלית TTF Indxx Semiconductor Equipment",
        "type": "tracking",
        "currency": "ILS",           # מנוטרלת דולר
        "benchmark": "Indxx Semiconductor Equipment Providers",
        "sector": "טכנולוגיה - סמיקונדקטורים",
    },
    "5142088": {
        "name": "קסם KTF MarketVector תעשיות ביטחוניות ישראליות",
        "type": "tracking",
        "currency": "ILS",
        "benchmark": "MarketVector Israel Defense",
        "sector": "ביטחון ישראל",
    },
    "5141882": {
        "name": "תכלית TTF אינדקס תעשיות ביטחוניות ישראל",
        "type": "tracking",
        "currency": "ILS",
        "benchmark": "אינדקס תעשיות ביטחוניות ישראל",
        "sector": "ביטחון ישראל",
    },
}

# ========================================
# Data class לנתוני קרן
# ========================================

@dataclass
class FundData:
    fund_id: str
    name: str
    fund_type: str        # "tracking" | "money_market"
    sector: str
    benchmark: str
    nav: Optional[float]          # שווי יחידה (NAV)
    nav_date: Optional[str]       # תאריך הנתון
    daily_change_pct: Optional[float]   # שינוי יומי באחוזים
    ytd_return_pct: Optional[float]     # תשואה מתחילת שנה
    management_fee: Optional[float]     # דמי ניהול
    fund_size_m: Optional[float]        # גודל קרן במיליוני ₪
    available: bool = True
    error: Optional[str] = None


# ========================================
# שליפת נתונים מ-MAYA API
# ========================================

MAYA_BASE_URL = "http://mayaapi.tase.co.il/api/fund/details"
MAYA_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "he-IL,he;q=0.9,en;q=0.8",
    "Referer": "https://maya.tase.co.il/",
    "Origin": "https://maya.tase.co.il",
}


def _parse_float(val) -> Optional[float]:
    """המרה בטוחה ל-float"""
    try:
        if val is None:
            return None
        return float(str(val).replace(",", "").replace("%", "").strip())
    except (ValueError, TypeError):
        return None


def get_fund_data(fund_id: str) -> FundData:
    """שליפת נתוני קרן בודדת מ-MAYA API"""
    meta = PORTFOLIO_FUNDS.get(fund_id, {})
    name = meta.get("name", f"קרן {fund_id}")
    fund_type = meta.get("type", "tracking")
    sector = meta.get("sector", "לא ידוע")
    benchmark = meta.get("benchmark", "")

    try:
        url = f"{MAYA_BASE_URL}?fundId={fund_id}"
        response = requests.get(url, headers=MAYA_HEADERS, timeout=10)
        response.raise_for_status()
        data = response.json()

        # MAYA API מחזיר את הנתונים ב-FundDetails
        fund_details = data.get("FundDetails", data)

        # NAV - שווי יחידה
        nav = _parse_float(
            fund_details.get("CalcPriceForSell") or
            fund_details.get("UnitValue") or
            fund_details.get("CurrentNav")
        )

        # תאריך
        nav_date = (
            fund_details.get("TradeDate") or
            fund_details.get("LastTradeDate") or
            str(date.today())
        )
        # ניקוי תאריך מפורמט ISO
        if nav_date and "T" in str(nav_date):
            nav_date = str(nav_date).split("T")[0]

        # שינוי יומי
        daily_change = _parse_float(
            fund_details.get("ChangePercent") or
            fund_details.get("DailyChangePercent")
        )

        # תשואה מתחילת שנה
        ytd = _parse_float(
            fund_details.get("YtdYield") or
            fund_details.get("YTDReturn") or
            fund_details.get("YearlyYield")
        )

        # דמי ניהול
        mgmt_fee = _parse_float(
            fund_details.get("ManagementFee") or
            fund_details.get("AdminFee")
        )

        # גודל קרן
        fund_size = _parse_float(
            fund_details.get("NetAssets") or
            fund_details.get("TotalAssets")
        )
        if fund_size and fund_size > 1_000_000:
            fund_size = fund_size / 1_000_000  # המרה למיליונים

        logger.info(f"✅ {fund_id} ({name}): NAV={nav}, שינוי={daily_change}%")

        return FundData(
            fund_id=fund_id,
            name=name,
            fund_type=fund_type,
            sector=sector,
            benchmark=benchmark,
            nav=nav,
            nav_date=nav_date,
            daily_change_pct=daily_change,
            ytd_return_pct=ytd,
            management_fee=mgmt_fee,
            fund_size_m=fund_size,
            available=True,
        )

    except requests.exceptions.RequestException as e:
        logger.warning(f"⚠️ שגיאת רשת עבור קרן {fund_id}: {e}")
        return FundData(
            fund_id=fund_id, name=name, fund_type=fund_type,
            sector=sector, benchmark=benchmark,
            nav=None, nav_date=None,
            daily_change_pct=None, ytd_return_pct=None,
            management_fee=None, fund_size_m=None,
            available=False, error=str(e)
        )
    except Exception as e:
        logger.error(f"❌ שגיאה בעיבוד נתוני קרן {fund_id}: {e}")
        return FundData(
            fund_id=fund_id, name=name, fund_type=fund_type,
            sector=sector, benchmark=benchmark,
            nav=None, nav_date=None,
            daily_change_pct=None, ytd_return_pct=None,
            management_fee=None, fund_size_m=None,
            available=False, error=str(e)
        )


def get_all_funds() -> list[FundData]:
    """שליפת נתוני כל הקרנות בתיק"""
    logger.info(f"🔄 שולף נתוני {len(PORTFOLIO_FUNDS)} קרנות נאמנות...")
    results = []
    for fund_id in PORTFOLIO_FUNDS:
        fund_data = get_fund_data(fund_id)
        results.append(fund_data)
    available = sum(1 for f in results if f.available)
    logger.info(f"✅ שליפה הושלמה: {available}/{len(results)} קרנות זמינות")
    return results


def format_funds_for_prompt(funds: list[FundData]) -> str:
    """פורמט נתוני קרנות להזרקה ל-prompt של Claude"""
    if not funds:
        return "לא נמצאו נתוני קרנות."

    lines = ["=== נתוני קרנות נאמנות בתיק ===", ""]

    # מיון: כספיות קודם, אחר כך מחקות
    money_market = [f for f in funds if f.fund_type == "money_market"]
    tracking = [f for f in funds if f.fund_type == "tracking"]

    if money_market:
        lines.append("-- קרנות כספיות --")
        for f in money_market:
            lines.append(_format_single_fund(f))
        lines.append("")

    if tracking:
        lines.append("-- קרנות מחקות (TTF) --")
        for f in tracking:
            lines.append(_format_single_fund(f))
        lines.append("")

    available = sum(1 for f in funds if f.available)
    lines.append(f"סה\"כ: {available}/{len(funds)} קרנות עם נתונים זמינים")
    lines.append(f"עדכון: {datetime.now().strftime('%d/%m/%Y %H:%M')}")

    return "\n".join(lines)


def _format_single_fund(f: FundData) -> str:
    """פורמט קרן בודדת לשורת טקסט"""
    if not f.available:
        return f"  ❌ {f.name} ({f.fund_id}) - נתונים לא זמינים: {f.error}"

    nav_str = f"₪{f.nav:.4f}" if f.nav else "N/A"
    change_str = ""
    if f.daily_change_pct is not None:
        sign = "+" if f.daily_change_pct >= 0 else ""
        change_str = f" | שינוי יומי: {sign}{f.daily_change_pct:.2f}%"

    ytd_str = ""
    if f.ytd_return_pct is not None:
        sign = "+" if f.ytd_return_pct >= 0 else ""
        ytd_str = f" | תשואה שנתית: {sign}{f.ytd_return_pct:.2f}%"

    fee_str = f" | דמי ניהול: {f.management_fee:.2f}%" if f.management_fee else ""
    size_str = f" | גודל: ₪{f.fund_size_m:.0f}M" if f.fund_size_m else ""

    return (
        f"  📊 {f.name}\n"
        f"     מזהה: {f.fund_id} | מדד: {f.benchmark}\n"
        f"     NAV: {nav_str}{change_str}{ytd_str}{fee_str}{size_str}"
    )


# ========================================
# בדיקה ישירה (python funds_connector.py)
# ========================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    print("\n🔍 בודק קרנות נאמנות בתיק...\n")

    all_funds = get_all_funds()

    print("\n" + "=" * 60)
    print(format_funds_for_prompt(all_funds))
    print("=" * 60)

    print("\n📋 סיכום JSON גולמי (לדיבאג):")
    for f in all_funds:
        status = "✅" if f.available else "❌"
        nav = f"₪{f.nav:.4f}" if f.nav else "N/A"
        print(f"  {status} [{f.fund_id}] {f.name}: {nav}")
